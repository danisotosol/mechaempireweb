<?php


$users_file = 'users.txt';


$action = $_POST['action'] ?? '';


function save_user($email, $name, $password) {
    global $users_file;
    $user_data = "{$email}|{$name}|" . password_hash($password, PASSWORD_DEFAULT) . "\n";
    file_put_contents($users_file, $user_data, FILE_APPEND);
}

/
function find_user_by_email($email) {
    global $users_file;
    if (!file_exists($users_file)) {
        return false;
    }
    $users = file($users_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($users as $user) {
        $parts = explode('|', $user);
        if ($parts[0] === $email) {
            return [
                'email' => $parts[0],
                'name' => $parts[1],
                'password' => $parts[2]
            ];
        }
    }
    return false;
}

switch ($action) {
    case 'register':
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        if (find_user_by_email($email)) {
            // Usuario ya existe
            header('Location: index.html?result=error_register');
        } else {
            // Registrar nuevo usuario
            save_user($email, $name, $password);
            header('Location: index.html?result=success_register');
        }
        break;

    case 'login':
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        $user = find_user_by_email($email);

        if ($user && password_verify($password, $user['password'])) {
            
            header('Location: index.html?result=success_login');
        } else {
            
            header('Location: index.html?result=error_login');
        }
        break;

    case 'forgot_password':
        $email = $_POST['email'] ?? '';
        if (find_user_by_email($email)) {

            header('Location: index.html?result=success_forgot');
        } else {
            
            header('Location: index.html?result=error_forgot');
        }
        break;

    default:
        
        header('Location: index.html');
        break;
}
exit();