document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const forgotPasswordForm = document.getElementById('forgot-password-form');
    const messageDisplay = document.getElementById('message');
    const welcomeMessage = document.getElementById('welcome-message');

    const showRegisterLink = document.getElementById('show-register');
    const showLoginFromRegisterLink = document.getElementById('show-login-from-register');
    const showForgotPasswordLink = document.getElementById('show-forgot-password');
    const showLoginFromForgotLink = document.getElementById('show-login-from-forgot');

    function showForm(formToShow) {
        loginForm.classList.remove('active');
        registerForm.classList.remove('active');
        forgotPasswordForm.classList.remove('active');
        formToShow.classList.add('active');
        messageDisplay.textContent = '';
        welcomeMessage.style.display = 'none';
    }

    showRegisterLink.addEventListener('click', (e) => {
        e.preventDefault();
        showForm(registerForm);
    });

    showLoginFromRegisterLink.addEventListener('click', (e) => {
        e.preventDefault();
        showForm(loginForm);
    });

    showForgotPasswordLink.addEventListener('click', (e) => {
        e.preventDefault();
        showForm(forgotPasswordForm);
    });

    showLoginFromForgotLink.addEventListener('click', (e) => {
        e.preventDefault();
        showForm(loginForm);
    });

    const urlParams = new URLSearchParams(window.location.search);
    const result = urlParams.get('result');

    if (result) {
        switch (result) {
            case 'success_login':
                welcomeMessage.style.display = 'block';
                loginForm.style.display = 'none';
                break;
            case 'error_login':
                messageDisplay.textContent = 'Sus credenciales son incorrectas';
                messageDisplay.style.color = 'red';
                showForm(loginForm);
                break;
            case 'success_register':
                messageDisplay.textContent = 'Registro completado con exito';
                messageDisplay.style.color = 'green';
                showForm(loginForm);
                break;
            case 'error_register':
                messageDisplay.textContent = 'Este usuario ya existe';
                messageDisplay.style.color = 'red';
                showForm(registerForm);
                break;
            case 'success_forgot':
                messageDisplay.textContent = 'Se envio correctaente a su correo electronico el enlace de recuperacion';
                messageDisplay.style.color = 'green';
                showForm(loginForm);
                break;
            case 'error_forgot':
                messageDisplay.textContent = 'Su correo electronico no aparece registrado';
                messageDisplay.style.color = 'red';
                showForm(forgotPasswordForm);
                break;
        }
    }
});