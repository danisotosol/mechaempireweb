<?php

require __DIR__ . '/../_bootstrap.php';
require_auth();

$uid = $_SESSION['user_id'];
$st = $pdo->prepare(
  "SELECT o.id, o.total, o.created_at,
          JSON_ARRAYAGG(JSON_OBJECT('title', p.title, 'quantity', oi.quantity, 'price', oi.price)) AS items
   FROM orders o
   JOIN order_items oi ON oi.order_id=o.id
   JOIN products p ON p.id=oi.product_id
   WHERE o.user_id=?
   GROUP BY o.id
   ORDER BY o.created_at DESC"
);
$st->execute([$uid]);
echo json_encode($st->fetchAll());
