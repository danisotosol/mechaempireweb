<?php

require __DIR__ . '/../_bootstrap.php';

$in = json_input();
$token   = $in['token'] ?? '';
$newpass = $in['new_password'] ?? '';

if (strlen($newpass) < 6) {
  http_response_code(400);
  echo json_encode(['error'=>'Contraseña muy corta']); exit;
}

$st = $pdo->prepare("SELECT id, user_id, used, expires_at FROM password_resets WHERE token=?");
$st->execute([$token]);
$row = $st->fetch();

if (!$row || $row['used'] || new DateTime($row['expires_at']) < new DateTime()) {
  http_response_code(400);
  echo json_encode(['error'=>'Token inválido']); exit;
}

$hash = password_hash($newpass, PASSWORD_BCRYPT);
$pdo->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([$hash, $row['user_id']]);
$pdo->prepare("UPDATE password_resets SET used=1 WHERE id=?")->execute([$row['id']]);

echo json_encode(['ok'=>true]);
