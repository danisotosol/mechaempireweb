<?php

require __DIR__ . '/../_bootstrap.php';

$in = json_input();
$email = strtolower(trim($in['email'] ?? ''));

$st = $pdo->prepare("SELECT id FROM users WHERE email=?");
$st->execute([$email]);
$u = $st->fetch();

if (!$u) { echo json_encode(['ok'=>true]); exit; } 

$token = bin2hex(random_bytes(16));
$expires = (new DateTime('+1 hour'))->format('Y-m-d H:i:s');

$pdo->prepare("INSERT INTO password_resets (user_id, token, expires_at) VALUES (?,?,?)")
    ->execute([$u['id'], $token, $expires]);


echo json_encode(['ok'=>true, 'token'=>$token]);
