<?php

require __DIR__ . '/../_bootstrap.php';
session_destroy();
echo json_encode(['ok'=>true]);
