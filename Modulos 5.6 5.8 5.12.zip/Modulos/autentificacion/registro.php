<?php

require __DIR__ . '/../_bootstrap.php';

$in = json_input();
$name = trim($in['name'] ?? '');
$email = strtolower(trim($in['email'] ?? ''));
$pass = $in['password'] ?? '';

if (!$name || !$email || strlen($pass) < 6) {
  http_response_code(400);
  echo json_encode(['error' => 'Datos inválidos']);
  exit;
}

try {
  $hash = password_hash($pass, PASSWORD_BCRYPT);
  // role_id = 2 => customer (asegúrate que exista en roles)
  $st = $pdo->prepare("INSERT INTO users (name, email, password_hash, role_id) VALUES (?,?,?,2)");
  $st->execute([$name, $email, $hash]);
  echo json_encode(['ok'=>true]);
} catch (PDOException $e) {
  http_response_code(400);
  echo json_encode(['error' => 'Email ya registrado']);
}

