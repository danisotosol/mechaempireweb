<?php

require __DIR__ . '/../_bootstrap.php';
echo json_encode(current_user($pdo));

