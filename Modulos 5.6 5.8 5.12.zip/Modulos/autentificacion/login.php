<?php

require __DIR__ . '/../_bootstrap.php';

$in = json_input();
$email = strtolower(trim($in['email'] ?? ''));
$pass  = $in['password'] ?? '';

$st = $pdo->prepare("SELECT id, password_hash FROM users WHERE email=?");
$st->execute([$email]);
$u = $st->fetch();

if (!$u || !password_verify($pass, $u['password_hash'])) {
  http_response_code(401);
  echo json_encode(['error'=>'Credenciales inválidas']); exit;
}

$_SESSION['user_id'] = $u['id'];
echo json_encode(['ok'=>true]);

