<?php

session_start();
header('Content-Type: application/json; charset=utf-8');


$DB_HOST = getenv('DB_HOST') ?: '127.0.0.1';
$DB_NAME = getenv('DB_NAME') ?: 'mechaempire';
$DB_USER = getenv('DB_USER') ?: 'root';
$DB_PASS = getenv('DB_PASS') ?: '';

try {
  $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch (PDOException $e) {
  http_response_code(500);
  echo json_encode(['error' => 'DB connection failed']);
  exit;
}

function json_input() {
  $raw = file_get_contents('php://input');
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}
function require_auth() {
  if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
  }
}
function current_user(PDO $pdo) {
  if (!isset($_SESSION['user_id'])) return null;
  $st = $pdo->prepare("SELECT u.id, u.name, u.email, r.name AS role
                       FROM users u JOIN roles r ON r.id=u.role_id
                       WHERE u.id=?");
  $st->execute([$_SESSION['user_id']]);
  return $st->fetch() ?: null;
}
