
INSERT INTO roles (name) VALUES ('admin'), ('customer');

INSERT INTO categories (slug, name) VALUES
 ('figuras-anime', 'Figuras Anime'),
 ('figuras-americanas', 'Figuras Americanas'),
 ('ropa-geek', 'Ropa Geek'),
 ('accesorios', 'Accesorios');


INSERT INTO users (name, email, password_hash, role_id)
VALUES ('Admin', 'admin@mechaempire.local',
  '$2y$10$po7KsxX0pR7rJUPaVRKmye3BIgHNSxfzD45cVjx/PKi6Wm5GkKr6u', 1);

INSERT INTO products (title, description, price, stock, category_id) VALUES
('Luffy Gear 5', 'Figura detallada de One Piece.', 59.99, 10, 1),
('Deku - My Hero Academia', 'Figura articulada.', 49.90, 5, 1),
('Batman Premium', 'Figura coleccionable DC.', 79.00, 3, 2),
('Camiseta Zelda', 'Talla M, algodón.', 19.99, 30, 3),
('Mochila Star Wars', 'Mochila temática.', 34.50, 12, 4);


INSERT INTO product_images (product_id, url) VALUES
(1, 'https://picsum.photos/seed/luffy/600/600'),
(2, 'https://picsum.photos/seed/deku/600/600'),
(3, 'https://picsum.photos/seed/batman/600/600'),
(4, 'https://picsum.photos/seed/zelda/600/600'),
(5, 'https://picsum.photos/seed/sw/600/600');
