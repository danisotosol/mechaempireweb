<?php

require __DIR__ . '/../_bootstrap.php';

$category = $_GET['category'] ?? null; 
$q = $_GET['q'] ?? null;

$sql = "SELECT p.id, p.title, p.price, p.stock, c.slug, c.name AS category,
        (SELECT url FROM product_images WHERE product_id=p.id LIMIT 1) AS image
        FROM products p
        JOIN categories c ON c.id=p.category_id";
$conds = [];
$args = [];

if ($category) { $conds[] = "c.slug = ?"; $args[] = $category; }
if ($q) { $conds[] = "p.title LIKE ?"; $args[] = "%$q%"; }
if ($conds) $sql .= " WHERE " . implode(" AND ", $conds);
$sql .= " ORDER BY p.created_at DESC";

$st = $pdo->prepare($sql);
$st->execute($args);
echo json_encode($st->fetchAll());
