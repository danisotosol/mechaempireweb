<?php

require __DIR__ . '/../_bootstrap.php';


$id = intval($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(400); echo json_encode(['error'=>'ID inválido']); exit; }

$st = $pdo->prepare("SELECT p.*, c.slug, c.name AS category
                     FROM products p
                     JOIN categories c ON c.id=p.category_id
                     WHERE p.id=?");
$st->execute([$id]);
$product = $st->fetch();
if (!$product) { http_response_code(404); echo json_encode(['error'=>'No encontrado']); exit; }

$imgs = $pdo->prepare("SELECT url FROM product_images WHERE product_id=?");
$imgs->execute([$id]);
$product['images'] = array_column($imgs->fetchAll(), 'url');

echo json_encode($product);
