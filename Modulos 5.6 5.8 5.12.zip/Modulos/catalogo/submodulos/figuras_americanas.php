<?php

require __DIR__ . '/../../_bootstrap.php';
$slug = 'figuras-americanas';
$st = $pdo->prepare(
  "SELECT p.id, p.title, p.price, p.stock, c.slug, c.name AS category,
          (SELECT url FROM product_images WHERE product_id=p.id LIMIT 1) AS image
   FROM products p JOIN categories c ON c.id=p.category_id
   WHERE c.slug=? ORDER BY p.created_at DESC"
);

$st->execute([$slug]);
echo json_encode($st->fetchAll());
