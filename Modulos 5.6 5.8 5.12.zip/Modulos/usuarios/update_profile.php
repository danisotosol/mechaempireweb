<?php

require __DIR__ . '/../_bootstrap.php';
require_auth();

$in = json_input();
$name = trim($in['name'] ?? '');
$email = strtolower(trim($in['email'] ?? ''));

if (!$name || !$email) {
  http_response_code(400);
  echo json_encode(['error'=>'Datos inválidos']); exit;
}
$uid = $_SESSION['user_id'];
$st = $pdo->prepare("UPDATE users SET name=?, email=? WHERE id=?");
$st->execute([$name, $email, $uid]);

echo json_encode(['ok'=>true]);
